using ProjetoSOLID.dados;
using ProjetoSOLID.model;
using ProjetoSOLID.view;
using System.Collections.Generic;

namespace ProjetoSOLID.controller
{
    public class CompraController
    {
        private readonly IRepository<Compra> repository;
        private readonly ICompraView view;
        private readonly ICadastroView<Compra> cadastroView;

        public CompraController(
            ICompraView view,
            IRepository<Compra> repository,
            ICadastroView<Compra> cadastroView)
        {
            this.view = view;
            this.repository = repository;
            this.cadastroView = cadastroView;
        }

        public void Cadastrar()
        {
            Compra compra = cadastroView.ObterDados();
            repository.Adicionar(compra);
            cadastroView.ExibirMensagem("Compra cadastrada com sucesso!");
        }

        public void Listar()
        {
            List<Compra> compras = repository.ListarTodos();

            if (compras.Count == 0)
            {
                cadastroView.ExibirMensagem("Nenhuma compra cadastrada.");
                return;
            }

            foreach (Compra compra in compras)
                view.MostrarCompra(compra);
        }

        public Compra Buscar(int id)
        {
            return repository.BuscarPorId(id);
        }

        public void Atualizar(Compra compra)
        {
            repository.Atualizar(compra);
        }

        public void Atualizar(int id)
        {
            Compra compra = Buscar(id);
            if (compra != null)
                repository.Atualizar(compra);
        }

        public void Remover(Compra compra)
        {
            if (compra != null)
                repository.Remover(compra);
        }

        public void Remover(int id)
        {
            repository.Remover(id);
        }
    }
}

using ProjetoSOLID.dados;
using ProjetoSOLID.model;
using ProjetoSOLID.view;
using System.Collections.Generic;

namespace ProjetoSOLID.controller
{
    public class ProdutoController
    {
        private readonly IRepository<Produto> repository;
        private readonly IProdutoView view;
        private readonly ICadastroView<Produto> cadastroView;

        public ProdutoController(IProdutoView view, IRepository<Produto> repository, ICadastroView<Produto> cadastroView)
        {
            this.view = view;
            this.repository = repository;
            this.cadastroView = cadastroView;
        }

        public void Cadastrar()
        {
            Produto produto = cadastroView.ObterDados();

            repository.Adicionar(produto);

            cadastroView.ExibirMensagem(
                "Produto cadastrado com sucesso!"
            );
        }

        public void Listar()
        {
            //duas maneiras de fazer:
            //1. Colocar um metodo pra exibir listas no view ou
            //2. Fazer um loop e chamar o exibir atual que o view ja tem

            List<Produto> produtos = repository.ListarTodos();
            foreach (Produto produto in produtos)
            {
                view.MostrarProduto(produto);
            }
        }

        public Produto Buscar(int id)
        {
            return repository.BuscarPorId(id);
        }

        public void Atualizar(Produto produto)
        {
            repository.Atualizar(produto);
        }

        public void Atualizar(int id)
        {
            repository.Atualizar(Buscar(id));
        }

        public void Remover(Produto p)
        {
            repository.Remover(p);
        }

        public void Remover(int id)
        {
            repository.Remover(id);
        }
    }
}

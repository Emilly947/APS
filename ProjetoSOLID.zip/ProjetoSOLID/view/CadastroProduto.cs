using ProjetoSOLID.model;
using System;

namespace ProjetoSOLID.view
{
    public class CadastroProduto : ICadastroView<Produto>
    {
        public void ExibirMensagem(string m)
        {

        }

        public Produto ObterDados()
        {
            Console.WriteLine("Nome :");
            string nome = Console.ReadLine();

            Console.WriteLine("Preço :");
            decimal preco = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Descrição :");
            string desc = Console.ReadLine();


            return new Produto(1, nome, preco, desc);
        }
    }
}
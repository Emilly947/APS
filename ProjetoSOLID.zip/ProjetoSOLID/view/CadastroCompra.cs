using ProjetoSOLID.model;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace ProjetoSOLID.view
{
    public class CadastroCompra : ICadastroView<Compra>
    {
        private readonly Func<int, Produto> buscarProduto;

        public CadastroCompra(Func<int, Produto> buscarProduto)
        {
            this.buscarProduto = buscarProduto;
        }

        public void ExibirMensagem(string m)
        {
            Console.WriteLine(m);
        }

        public Compra ObterDados()
        {
            Console.Write("Data da compra (dd/MM/yyyy): ");
            DateTime data = DateTime.ParseExact(
                Console.ReadLine(), "dd/MM/yyyy", CultureInfo.InvariantCulture);

            List<Produto> produtos = new List<Produto>();

            Console.Write("ID do produto (0 para finalizar): ");
            while (int.TryParse(Console.ReadLine(), out int id) && id != 0)
            {
                Produto produto = buscarProduto(id);

                if (produto == null)
                    Console.WriteLine("Produto não encontrado.");
                else if (produtos.Exists(p => p.Id == produto.Id))
                    Console.WriteLine("Esse produto já foi adicionado à compra.");
                else
                {
                    produtos.Add(produto);
                    Console.WriteLine("Produto adicionado: " + produto.Nome);
                }

                Console.Write("ID do próximo produto (0 para finalizar): ");
            }

            return new Compra(0, data, produtos);
        }
    }
}

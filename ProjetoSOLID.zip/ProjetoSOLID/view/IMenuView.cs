namespace ProjetoSOLID.view
{
    internal interface IMenuView
    {
        int ExibirMenu();
    }
}

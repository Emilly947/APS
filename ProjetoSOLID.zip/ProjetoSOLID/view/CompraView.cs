using ProjetoSOLID.model;
using System;

namespace ProjetoSOLID.view
{
    public class CompraView : ICompraView
    {
        public void MostrarCompra(Compra compra)
        {
            Console.WriteLine("--- COMPRA ---");
            Console.WriteLine("ID: " + compra.Id);
            Console.WriteLine("Data: " + compra.Data.ToString("dd/MM/yyyy"));
            Console.WriteLine("Produtos:");

            foreach (Produto produto in compra.Produtos)
                Console.WriteLine("  " + produto.Id + " - " + produto.Nome + " - " + produto.Preco.ToString("C2"));

            Console.WriteLine("Total: " + compra.Total.ToString("C2"));
            Console.WriteLine();
        }
    }
}

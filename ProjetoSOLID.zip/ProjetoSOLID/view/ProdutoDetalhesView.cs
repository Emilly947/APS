﻿using ProjetoSOLID.model;
using System;

namespace ProjetoSOLID.view
{
    public class ProdutoDetalhesView : IProdutoView
    {
        public void MostrarProduto(Produto produto)
        {
            Console.WriteLine("--- DETALHES DO PRODUTO ---");
            Console.WriteLine($"Nome: {produto.Nome}");
            Console.WriteLine($"Preço: {produto.Preco:C2}");
            Console.WriteLine($"Descrição: {produto.Descricao}");
        }
    }
}

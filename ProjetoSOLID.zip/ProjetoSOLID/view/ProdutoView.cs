﻿using ProjetoSOLID.model;
using System;

namespace ProjetoSOLID.view
{
    public class ProdutoView : IProdutoView
    {
        public void MostrarProduto(Produto produto)
        {
            Console.WriteLine("--- PRODUTO ---");
            Console.WriteLine($"Nome: {produto.Nome}");
            Console.WriteLine($"Preço: {produto.Preco:C2}");
        }
    }
}

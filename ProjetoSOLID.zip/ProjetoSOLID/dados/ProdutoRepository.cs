using ProjetoSOLID.model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ProjetoSOLID.dados
{
    public class ProdutoRepository : IRepository<Produto>
    {
        public void Adicionar(Produto novo)
        {
            const string sql = @"
INSERT INTO Produtos (Nome, Preco, Descricao)
OUTPUT INSERTED.Id
VALUES (@Nome, @Preco, @Descricao);";

            using (SqlConnection db = Database.AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(sql, db))
            {
                cmd.Parameters.AddWithValue("@Nome", novo.Nome);
                cmd.Parameters.AddWithValue("@Preco", novo.Preco);
                cmd.Parameters.AddWithValue("@Descricao", (object)novo.Descricao ?? DBNull.Value);
                novo.DefinirId(Convert.ToInt32(cmd.ExecuteScalar()));
            }
        }

        public List<Produto> ListarTodos()
        {
            List<Produto> lista = new List<Produto>();

            using (SqlConnection db = Database.AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(
                "SELECT Id, Nome, Preco, Descricao FROM Produtos ORDER BY Id", db))
            using (SqlDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                    lista.Add(Mapear(r));
            }
            return lista;
        }

        public Produto BuscarPorId(int id)
        {
            using (SqlConnection db = Database.AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(
                "SELECT Id, Nome, Preco, Descricao FROM Produtos WHERE Id=@Id", db))
            {
                cmd.Parameters.AddWithValue("@Id", id);
                using (SqlDataReader r = cmd.ExecuteReader())
                    return r.Read() ? Mapear(r) : null;
            }
        }

        public void Atualizar(Produto entidade)
        {
            if (entidade == null) throw new ArgumentNullException("entidade");

            using (SqlConnection db = Database.AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(@"
UPDATE Produtos
SET Nome=@Nome, Preco=@Preco, Descricao=@Descricao
WHERE Id=@Id;", db))
            {
                cmd.Parameters.AddWithValue("@Id", entidade.Id);
                cmd.Parameters.AddWithValue("@Nome", entidade.Nome);
                cmd.Parameters.AddWithValue("@Preco", entidade.Preco);
                cmd.Parameters.AddWithValue("@Descricao", (object)entidade.Descricao ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }
        }

        public void Remover(Produto entidade)
        {
            if (entidade != null) Remover(entidade.Id);
        }

        public void Remover(int id)
        {
            using (SqlConnection db = Database.AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(
                "DELETE FROM Produtos WHERE Id=@Id", db))
            {
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
            }
        }

        private Produto Mapear(SqlDataReader r)
        {
            return new Produto(
                Convert.ToInt32(r["Id"]),
                Convert.ToString(r["Nome"]),
                Convert.ToDecimal(r["Preco"]),
                r["Descricao"] == DBNull.Value ? "" : Convert.ToString(r["Descricao"]));
        }
    }
}

using System;
using System.Configuration;
using System.Data.SqlClient;

namespace ProjetoSOLID.dados
{
    public static class Database
    {
        public static SqlConnection AbrirConexao()
        {
            string cs = ConfigurationManager.ConnectionStrings["ProjetoSOLID"].ConnectionString;
            SqlConnection conexao = new SqlConnection(cs);
            conexao.Open();
            return conexao;
        }

        public static void Inicializar()
        {
            const string masterCs =
                "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;TrustServerCertificate=True";

            using (SqlConnection master = new SqlConnection(masterCs))
            {
                master.Open();
                using (SqlCommand cmd = new SqlCommand(
                    "IF DB_ID('ProjetoSOLID') IS NULL CREATE DATABASE ProjetoSOLID;", master))
                {
                    cmd.ExecuteNonQuery();
                }
            }

            using (SqlConnection db = AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(@"
IF OBJECT_ID('dbo.Produtos','U') IS NULL
BEGIN
    CREATE TABLE dbo.Produtos (
        Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Nome NVARCHAR(100) NOT NULL,
        Preco DECIMAL(18,2) NOT NULL,
        Descricao NVARCHAR(500) NULL
    );
END;

IF OBJECT_ID('dbo.Compras','U') IS NULL
BEGIN
    CREATE TABLE dbo.Compras (
        Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Data DATETIME2 NOT NULL
    );
END;

IF OBJECT_ID('dbo.CompraProdutos','U') IS NULL
BEGIN
    CREATE TABLE dbo.CompraProdutos (
        CompraId INT NOT NULL,
        ProdutoId INT NOT NULL,
        CONSTRAINT PK_CompraProdutos PRIMARY KEY (CompraId, ProdutoId),
        CONSTRAINT FK_CompraProdutos_Compra FOREIGN KEY (CompraId)
            REFERENCES dbo.Compras(Id) ON DELETE CASCADE,
        CONSTRAINT FK_CompraProdutos_Produto FOREIGN KEY (ProdutoId)
            REFERENCES dbo.Produtos(Id)
    );
END;", db))
            {
                cmd.ExecuteNonQuery();
            }
        }
    }
}

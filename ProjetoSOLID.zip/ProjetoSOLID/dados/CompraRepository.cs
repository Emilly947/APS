using ProjetoSOLID.model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ProjetoSOLID.dados
{
    public class CompraRepository : IRepository<Compra>
    {
        public void Adicionar(Compra nova)
        {
            using (SqlConnection db = Database.AbrirConexao())
            using (SqlTransaction tx = db.BeginTransaction())
            {
                try
                {
                    int id;
                    using (SqlCommand cmd = new SqlCommand(
                        "INSERT INTO Compras (Data) OUTPUT INSERTED.Id VALUES (@Data);",
                        db, tx))
                    {
                        cmd.Parameters.AddWithValue("@Data", nova.Data);
                        id = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    foreach (Produto produto in nova.Produtos)
                    {
                        InserirProdutoCompra(db, tx, id, produto.Id);
                    }

                    tx.Commit();
                    nova.DefinirId(id);
                }
                catch
                {
                    tx.Rollback();
                    throw;
                }
            }
        }

        public List<Compra> ListarTodos()
        {
            List<Compra> compras = new List<Compra>();

            using (SqlConnection db = Database.AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(@"
SELECT c.Id, c.Data, p.Id AS ProdutoId, p.Nome, p.Preco, p.Descricao
FROM Compras c
LEFT JOIN CompraProdutos cp ON cp.CompraId = c.Id
LEFT JOIN Produtos p ON p.Id = cp.ProdutoId
ORDER BY c.Id, p.Id;", db))
            using (SqlDataReader r = cmd.ExecuteReader())
            {
                Dictionary<int, Compra> mapa = new Dictionary<int, Compra>();

                while (r.Read())
                {
                    int compraId = Convert.ToInt32(r["Id"]);

                    if (!mapa.ContainsKey(compraId))
                        mapa[compraId] = new Compra(
                            compraId,
                            Convert.ToDateTime(r["Data"]),
                            new List<Produto>());

                    if (r["ProdutoId"] != DBNull.Value)
                    {
                        mapa[compraId].Produtos.Add(new Produto(
                            Convert.ToInt32(r["ProdutoId"]),
                            Convert.ToString(r["Nome"]),
                            Convert.ToDecimal(r["Preco"]),
                            r["Descricao"] == DBNull.Value ? "" : Convert.ToString(r["Descricao"])));
                    }
                }

                compras.AddRange(mapa.Values);
            }

            return compras;
        }

        public Compra BuscarPorId(int id)
        {
            using (SqlConnection db = Database.AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(@"
SELECT c.Id, c.Data, p.Id AS ProdutoId, p.Nome, p.Preco, p.Descricao
FROM Compras c
LEFT JOIN CompraProdutos cp ON cp.CompraId = c.Id
LEFT JOIN Produtos p ON p.Id = cp.ProdutoId
WHERE c.Id=@Id
ORDER BY p.Id;", db))
            {
                cmd.Parameters.AddWithValue("@Id", id);

                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    Compra compra = null;
                    List<Produto> produtos = new List<Produto>();

                    while (r.Read())
                    {
                        if (compra == null)
                        {
                            compra = new Compra(
                                Convert.ToInt32(r["Id"]),
                                Convert.ToDateTime(r["Data"]),
                                new List<Produto>());
                        }

                        if (r["ProdutoId"] != DBNull.Value)
                        {
                            produtos.Add(new Produto(
                                Convert.ToInt32(r["ProdutoId"]),
                                Convert.ToString(r["Nome"]),
                                Convert.ToDecimal(r["Preco"]),
                                r["Descricao"] == DBNull.Value ? "" : Convert.ToString(r["Descricao"])));
                        }
                    }

                    if (compra != null)
                        compra.Atualizar(compra.Data, produtos);

                    return compra;
                }
            }
        }

        public void Atualizar(Compra entidade)
        {
            if (entidade == null) throw new ArgumentNullException("entidade");

            using (SqlConnection db = Database.AbrirConexao())
            using (SqlTransaction tx = db.BeginTransaction())
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(
                        "UPDATE Compras SET Data=@Data WHERE Id=@Id;", db, tx))
                    {
                        cmd.Parameters.AddWithValue("@Id", entidade.Id);
                        cmd.Parameters.AddWithValue("@Data", entidade.Data);
                        cmd.ExecuteNonQuery();
                    }

                    using (SqlCommand cmd = new SqlCommand(
                        "DELETE FROM CompraProdutos WHERE CompraId=@Id;", db, tx))
                    {
                        cmd.Parameters.AddWithValue("@Id", entidade.Id);
                        cmd.ExecuteNonQuery();
                    }

                    foreach (Produto produto in entidade.Produtos)
                        InserirProdutoCompra(db, tx, entidade.Id, produto.Id);

                    tx.Commit();
                }
                catch
                {
                    tx.Rollback();
                    throw;
                }
            }
        }

        public void Remover(Compra entidade)
        {
            if (entidade != null) Remover(entidade.Id);
        }

        public void Remover(int id)
        {
            using (SqlConnection db = Database.AbrirConexao())
            using (SqlCommand cmd = new SqlCommand(
                "DELETE FROM Compras WHERE Id=@Id", db))
            {
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
            }
        }

        private void InserirProdutoCompra(
            SqlConnection db, SqlTransaction tx, int compraId, int produtoId)
        {
            using (SqlCommand cmd = new SqlCommand(
                "INSERT INTO CompraProdutos (CompraId, ProdutoId) VALUES (@CompraId,@ProdutoId);",
                db, tx))
            {
                cmd.Parameters.AddWithValue("@CompraId", compraId);
                cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                cmd.ExecuteNonQuery();
            }
        }
    }
}

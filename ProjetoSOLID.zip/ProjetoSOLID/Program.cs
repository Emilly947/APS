﻿using ProjetoSOLID.controller;
using ProjetoSOLID.dados;
using ProjetoSOLID.model;
using ProjetoSOLID.view;
using System;
using System.Collections.Generic;

namespace ProjetoSOLID
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IRepository<Produto> repository = new ListaProdutos();
            IProdutoView produtoView = new ProdutoView();
            ICadastroView<Produto> cadastroView = new CadastroProduto();
            IMenuView menuView = new MenuConsoleView();

            ProdutoController controller = new
                ProdutoController(produtoView, repository,
                cadastroView);

            int opcao;

            do
            {
                opcao = menuView.ExibirMenu();

                Console.Clear();
                switch (opcao)
                {
                    case 1:
                        controller.Cadastrar();
                        break;

                    case 2:
                        controller.Listar();
                        break;

                    case 3:
                        Console.Write("Informe o ID: ");

                        if (int.TryParse(Console.ReadLine(), out int idBusca))
                        {
                            Produto produto = controller.Buscar(idBusca);

                            if (produto != null)
                                produtoView.MostrarProduto(produto);
                            else
                                Console.WriteLine("Produto não encontrado.");
                        }
                        else
                        {
                            Console.WriteLine("ID inválido.");
                        }
                        break;

                    case 4:
                        Console.WriteLine(
                            "Atualização ainda não implementada."
                        );
                        break;

                    case 5:
                        Console.Write("Informe o ID: ");

                        if (int.TryParse(Console.ReadLine(), out int idExcluir))
                        {
                            controller.Remover(idExcluir);
                            Console.WriteLine("Operação de exclusão concluída.");
                        }
                        else
                        {
                            Console.WriteLine("ID inválido.");
                        }
                        break;

                    case 0:
                        Console.WriteLine("Encerrando o sistema...");
                        break;

                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }

                if (opcao != 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("Pressione qualquer tecla para continuar...");
                    Console.ReadKey();
                }

            } while (opcao != 0);

            ICompraView compraView = new ICompraView();

            CompraController compraController = new
               CompraController(compraView, compraRepository);

        }
    }
}

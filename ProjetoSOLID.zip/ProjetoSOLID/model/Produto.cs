﻿using System;

namespace ProjetoSOLID.model
{
    public class Produto
    {
        public int Id { get; }
        public string Nome { get; private set; }
        public decimal Preco { get; private set; }
        public string Descricao { get; private set; }

        public Produto(int id, string nome, decimal preco, string descricao = "")
        {
            if (id <= 0)
            {
                throw new ArgumentException("O ID deve ser positivo.");
            }

            Id = id;
            Atualizar(nome, preco, descricao);
        }

        public void Atualizar(string nome, decimal preco, string descricao)
        {
            if (string.IsNullOrWhiteSpace(nome))
            {
                throw new ArgumentNullException("O nome não pode ser vazio.");
            }

            if (preco < 0)
            {
                throw new ArgumentNullException("O preço não pode ser negativo.");
            }

            Nome = nome.Trim();
            Preco = preco;
            Descricao = descricao.Trim();
        }
    }
}

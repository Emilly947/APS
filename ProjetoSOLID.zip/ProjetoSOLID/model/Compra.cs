using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoSOLID.model
{
    public class Compra
    {
        public int Id { get; private set; }
        public DateTime Data { get; private set; }
        public List<Produto> Produtos { get; private set; }

        public decimal Total
        {
            get { return Produtos.Sum(p => p.Preco); }
        }

        public Compra(int id, DateTime data, IEnumerable<Produto> produtos)
        {
            if (id < 0) throw new ArgumentException("O ID não pode ser negativo.");
            Id = id;
            Atualizar(data, produtos);
        }

        public void Atualizar(DateTime data, IEnumerable<Produto> produtos)
        {
            if (produtos == null) throw new ArgumentNullException("produtos");

            List<Produto> lista = produtos.ToList();
            if (lista.Count == 0)
                throw new ArgumentException("A compra precisa ter pelo menos um produto.");

            Data = data;
            Produtos = lista;
        }

        internal void DefinirId(int id)
        {
            if (id <= 0) throw new ArgumentException("ID inválido.");
            Id = id;
        }
    }
}
